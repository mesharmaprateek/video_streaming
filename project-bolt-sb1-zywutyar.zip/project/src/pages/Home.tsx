import React, { useEffect } from 'react';
import { useVideoStore } from '../store/videoStore';
import { Link } from 'react-router-dom';
import { Play, Heart } from 'lucide-react';

function Home() {
  const { videos, setVideos } = useVideoStore();

  useEffect(() => {
    // Fetch videos from Supabase
    const fetchVideos = async () => {
      // Implementation will be added later
    };
    fetchVideos();
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {videos.map((video) => (
        <Link
          key={video.id}
          to={`/video/${video.id}`}
          className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
        >
          <div className="relative">
            <img
              src={video.thumbnail_url}
              alt={video.title}
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
              <Play className="h-12 w-12 text-white" />
            </div>
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-lg mb-2">{video.title}</h3>
            <p className="text-gray-600 text-sm line-clamp-2">{video.summary}</p>
            <div className="flex items-center justify-between mt-4">
              <span className="text-sm text-gray-500">
                {new Date(video.created_at).toLocaleDateString()}
              </span>
              <div className="flex items-center space-x-1">
                <Heart className="h-5 w-5 text-red-500" />
                <span className="text-sm">{video.likes_count}</span>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default Home;
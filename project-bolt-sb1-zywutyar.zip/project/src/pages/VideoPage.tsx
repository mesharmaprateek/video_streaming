import React from 'react';
import { useParams } from 'react-router-dom';
import { useVideoStore } from '../store/videoStore';
import { Heart, Bookmark } from 'lucide-react';

function VideoPage() {
  const { id } = useParams();
  const { videos, toggleBookmark, addLike, bookmarkedVideos } = useVideoStore();
  const video = videos.find((v) => v.id === id);

  if (!video) {
    return <div>Loading...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-black aspect-video rounded-lg overflow-hidden">
        <video
          src={video.video_url}
          controls
          className="w-full h-full"
          poster={video.thumbnail_url}
        />
      </div>
      
      <div className="mt-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">{video.title}</h1>
          <div className="flex space-x-4">
            <button
              onClick={() => addLike(video.id)}
              className="flex items-center space-x-1 text-red-500"
            >
              <Heart className="h-6 w-6" />
              <span>{video.likes_count}</span>
            </button>
            <button
              onClick={() => toggleBookmark(video.id)}
              className={`flex items-center space-x-1 ${
                bookmarkedVideos.includes(video.id) ? 'text-blue-500' : 'text-gray-500'
              }`}
            >
              <Bookmark className="h-6 w-6" />
              <span>Bookmark</span>
            </button>
          </div>
        </div>
        
        <p className="mt-4 text-gray-600">{video.summary}</p>
        
        {video.is_premium && (
          <div className="mt-6 bg-blue-50 p-4 rounded-lg">
            <p className="text-blue-800 font-medium">
              This is a premium video. Subscribe to watch.
            </p>
            <button className="mt-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
              Subscribe Now
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default VideoPage;
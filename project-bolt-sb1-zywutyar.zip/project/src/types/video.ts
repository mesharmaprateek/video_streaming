export interface Video {
  id: string;
  title: string;
  summary: string;
  thumbnail_url: string;
  video_url: string;
  category: string;
  is_premium: boolean;
  created_at: string;
  likes_count: number;
}

export interface VideoStore {
  videos: Video[];
  bookmarkedVideos: string[];
  setVideos: (videos: Video[]) => void;
  toggleBookmark: (videoId: string) => void;
  addLike: (videoId: string) => void;
}
import { create } from 'zustand';
import { VideoStore } from '../types/video';

export const useVideoStore = create<VideoStore>((set) => ({
  videos: [],
  bookmarkedVideos: [],
  setVideos: (videos) => set({ videos }),
  toggleBookmark: (videoId) =>
    set((state) => ({
      bookmarkedVideos: state.bookmarkedVideos.includes(videoId)
        ? state.bookmarkedVideos.filter((id) => id !== videoId)
        : [...state.bookmarkedVideos, videoId],
    })),
  addLike: (videoId) =>
    set((state) => ({
      videos: state.videos.map((video) =>
        video.id === videoId
          ? { ...video, likes_count: video.likes_count + 1 }
          : video
      ),
    })),
}));